
If you cannot get started and always receive the warning message "The RASTOP.EXE file is linked to missing MFC42.DLL:6605", install the file mfc42.dll in the folder containing the RasTop.exe file. 


If you cannot get started and always receive the warning message indicating that either MFC42D.DLL or MSVCRTD.dll is missing, download the file rastop-dll.zip. Unzip the patch and install both dlls, MFC42D.DLL and MSVCRTD.dll, in the folder containing the RasTop.exe file. 


